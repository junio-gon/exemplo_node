// require("dotenv").config({
//     path: process.env.NODE_ENV == "test" ? ".env.test" : ".env"
// });
import dotenv from 'dotenv';
import express from 'express';
import 'express-async-errors';
import './database/connection';
import routes from './routes';
import errorHandler from './errors/handler';
import cors from 'cors';
import log4js from './errors/logs';

dotenv.config({
    path: process.env.NODE_ENV === "test" ? ".env.test" : ".env"
});

const app = express();
const port = 3333;

app.use(express.json());

app.use(cors());
/*
    app.use(cors{
        origin: '<endereço_da_aplicação>'
    });
*/

//routes file
app.use(routes);

//errors file
app.use(errorHandler);

//server port
var loggererror = log4js.getLogger('error');
var loggerinfo = log4js.getLogger('info');
try {
    app.listen(process.env.PORT || port, () => {
        loggerinfo.info(`App uped at http://localhot:${process.env.PORT || port}`);
    })
} catch (error) {
    loggererror.error(error.message + ' on ' + module.filename);
}