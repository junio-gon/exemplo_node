import { ErrorRequestHandler } from 'express';
import { ValidationError } from 'yup';
import log4js from './logs';

interface ValidationErrors {
    [key: string]: string[];
}

const errorHandler: ErrorRequestHandler = (error, request, response, next) => {
    var loggererror = log4js.getLogger('error');
    if (error instanceof ValidationError) {
        let errors: ValidationErrors = {};
        error.inner.forEach(err => {
            errors[err.path] = err.errors;
        });
        console.error(error)
        loggererror.error(error);
        return response.status(400).json({
            message: 'Ocorreu um erro na validação dos seguintes campos: ', errors
        });
    }
    console.error(error);
    loggererror.error(error);
    return response.status(500).json({ 
        message: 'Ocorreu um erro interno' 
    });
}

export default errorHandler;