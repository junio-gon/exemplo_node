let fs = require('fs');

fs.unlink('../backend/logs/logs.log', function (err: any){
    if (err) throw err;
})

var log4js = require('log4js');
log4js.configure({
  appenders: { 'file': { type: 'file', filename: 'logs/logs.log' } },
  categories: { default: { appenders: ['file'], level: 'debug' } }
});

export default (log4js);