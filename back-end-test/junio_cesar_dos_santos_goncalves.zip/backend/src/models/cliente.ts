import { Entity, Column, PrimaryGeneratedColumn, OneToMany, JoinColumn } from 'typeorm';
import Item from './item'

@Entity('clientes')
export default class Clientes{
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column()
    nome: string;

    @Column()
    email: string;

    @Column()
    cpf: string;

    @Column()
    cep: string;

    @Column()
    frete: string;

    @Column()
    valor: string;

    @Column()
    created_at: Date;

    @Column()
    modified_at: Date;

    @OneToMany(() => Item, item => item.cliente, {
        cascade: ['insert', 'update']
    })
    @JoinColumn({ name: 'cliente_id' })
    item: Item[];

    // @OneToMany(() => Question, question => question.research, {
    //     cascade: ['insert', 'update']
    // })
    // @JoinColumn({ name: 'research_id' })
    // questions: Question[];
}