import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import Cliente from './cliente';

@Entity('itens')
export default class Question{
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column()
    sku: number;

    @Column()
    descricao: string;

    @Column()
    valor: string;

    @Column()
    quantidade: string;

    @Column()
    cliente_id: string;

    @Column()
    created_at: Date;

    @Column()
    modified_at: Date;

    @ManyToOne(() => Cliente, cliente => cliente.item)
    @JoinColumn({ name: 'cliente_id' })
    cliente: Cliente;

    // @OneToMany(() => Option, option => option.question, {
    //     cascade: ['insert', 'update']
    // })
    // @JoinColumn({ name: 'question_id' })
    // options: Option[];
}