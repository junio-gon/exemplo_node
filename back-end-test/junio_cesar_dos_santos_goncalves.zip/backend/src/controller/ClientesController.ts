import { Request, Response } from 'express';
import { getRepository } from 'typeorm';
import Cliente from '../models/cliente';
import clienteView from '../views/clientes_view';
import * as Yup from 'yup';
import log4js from '../errors/logs';

export default {
    //GET ==> Get All
    async index(request: Request, response: Response) {
        const clientesRepository = getRepository(Cliente);
        const researches = await clientesRepository.find();
        return response.status(200).json(clienteView.renderMany(researches));
    },
    
    //GET/ID ==> Get one
    async show(request: Request, response: Response) {
        const { id } = request.params;
        const clientesRepository = getRepository(Cliente);
        try {
            const cliente = await clientesRepository.findOneOrFail(id); 
            return response.status(200).json(clienteView.render(cliente));
        } catch (error) {
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    },

    //DELETE/ID ==> delete um usuário
    async delete(request: Request, response: Response) {
        const { id } = request.params;
        const clienteRepository = getRepository(Cliente);
        try {
            const cliente = await clienteRepository.delete(id);
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Excluido com sucesso: ${id} on ${module.filename}`);
            return response.status(200).json({id: id, message: 'Excluido com sucesso'});
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao excluir Cliente: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    },
    
    //POST ==> Cria usuário
    async create(request: Request, response: Response) {
        const{
            nome,
            email,
            cpf,
            cep,
            frete,
            valor,
            created_at,
        } = request.body;
        const clientesRepository = getRepository(Cliente);
        let data = {
            nome,
            email,
            cpf,
            cep,
            frete,
            valor,
            created_at,
        }
        const now = new Date;
        data.created_at = now;
        const schema = Yup.object().shape({
            nome   : Yup.string()
                    .required('Nome é um campo obrigatório'),
            email  : Yup.string()
                    .required('Email é um campo obrigatório')
                    .email('O campo infomado não é um e-mail válido'),
            cpf   : Yup.string()
                    .required('CPF é um campo obrigatório')
                    .max(15, 'CFP informado possui formato inválido')
                    .min(12, 'CFP informado possui formato inválido'),
            cep   : Yup.string()
                    .required('CEP é um campo obrigatório')
                    .max(10, 'CEP informado possui formato inválido')
                    .min(8, 'CEP informado possui formato inválido'),
            frete : Yup.number()
                    .required('Frete é um campo obrigatório')
                    .typeError("O valor informado não é numérico"),
            valor : Yup.number()
                    .required('Valor é um campo obrigatório')
                    .typeError("O valor informado não é numérico")
        });
        await schema.validate(data, {
            abortEarly: false
        });
        const clientes = clientesRepository.create(data);
        try {
            await clientesRepository.save(clientes);
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Criado com sucesso: ${JSON.stringify(clientes)} on ${module.filename}`);
            return response.status(201).json(clientes);
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao inserir Cliente: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
        /*
        exemplo:
        {
            "nome": "Junio Santos",
            "email": "junio@junio.com",
            "cpf": "333.333.333-33",
            "cep": "33.333-333",
        	"frete": 50.00,
        	"valor": 200.00
        }
        */
    },
    
    //PUT ==> Udate de Usuário
    async update(request: Request, response: Response) {
        const{
            id,
            nome,
            email,
            cpf,
            cep,
            frete,
            valor,
            created_at,
            modified_at
        } = request.body;
        const clientesRepository = getRepository(Cliente);
        let data = {
            id,
            nome,
            email,
            cpf,
            cep,
            frete,
            valor,
            created_at,
            modified_at
        }
        const now = new Date;
        data.modified_at = now;
        const schema = Yup.object().shape({
            id     : Yup.number()
                    .required('Para update é necessário informar o ID')
                    .typeError("O ID informado não é numérico"),
            nome   : Yup.string()
                    .required('Nome é um campo obrigatório'),
            email  : Yup.string()
                    .required('Email é um campo obrigatório')
                    .email('O campo infomado não é um e-mail válido'),
            cpf   : Yup.string()
                    .required('CPF é um campo obrigatório')
                    .max(15, 'CFP informado possui formato inválido')
                    .min(12, 'CFP informado possui formato inválido'),
            cep   : Yup.string()
                    .required('CEP é um campo obrigatório')
                    .max(10, 'CEP informado possui formato inválido')
                    .min(8, 'CEP informado possui formato inválido'),
            frete : Yup.number()
                    .required('Frete é um campo obrigatório')
                    .typeError("O valor informado não é numérico"),
            valor : Yup.number()
                    .required('Valor é um campo obrigatório')
                    .typeError("O valor informado não é numérico")
        })
        await schema.validate(data, {
            abortEarly: false
        });
        const cliente = clientesRepository.create(data);
        try {
            await clientesRepository.update(
                { id: data.id },
                cliente
            );
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Alterado com sucesso: ${JSON.stringify(cliente)} on ${module.filename}`);
            return response.status(201).json(cliente);
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao executar o update do Cliente: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    }
};