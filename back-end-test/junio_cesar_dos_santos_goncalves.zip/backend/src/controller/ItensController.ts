import { Request, Response } from 'express';
import { getRepository } from 'typeorm';
import Item from '../models/item';
import ItemView from '../views/itens_view';
import * as Yup from 'yup';
import log4js from '../errors/logs';

export default {
    //GET ==> Get All
    async index(request: Request, response: Response) {
        const itensRepository = getRepository(Item);
        const item = await itensRepository.find();
        return response.status(200).json(ItemView.renderMany(item));
    },
    
    //GET/ID ==> Get one
    async show(request: Request, response: Response) {
        const { id } = request.params;
        const itensRepository = getRepository(Item);
        try {
            const item = await itensRepository.findOneOrFail(id); 
            return response.status(200).json(ItemView.render(item));
        } catch (error) {
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    },

    //DELETE/ID ==> delete um item
    async delete(request: Request, response: Response) {
        const { id } = request.params;
        const itensRepository = getRepository(Item);
        try {
            const item = await itensRepository.delete(id);
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Excluido com sucesso: ${id} on ${module.filename}`);
            return response.status(200).json({id: id, message: 'Excluido com sucesso'});
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao excluir Item: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    },
    
    //POST ==> Cria item
    async create(request: Request, response: Response) {
        const{
            sku,
            descricao,
            valor,
            quantidade,
            created_at,
            cliente_id
        } = request.body;
        const itensRepository = getRepository(Item);
        let data = {
            sku,
            descricao,
            valor,
            quantidade,
            created_at,
            cliente_id
        }
        const now = new Date;
        data.created_at = now;
        const schema = Yup.object().shape({
            sku       : Yup.string()
                        .required('Nome é um campo obrigatório'),
            descricao  : Yup.string()
                        .required('Descrição é um campo obrigatório'),
            valor     : Yup.number()
                        .required('Valor é um campo obrigatório')
                        .typeError("O valor informado não é numérico"),
            quantidade : Yup.number()
                        .required('Quantidade é um campo obrigatório')
                        .typeError("O valor informado não é numérico"),
            cliente_id : Yup.number()
                        .required('Quantidade é um campo obrigatório')
                        .typeError("O valor informado não é numérico")
        });    
        await schema.validate(data, {
            abortEarly: false
        });
        const item = itensRepository.create(data);
        try {
            await itensRepository.save(item);
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Criado com sucesso: ${JSON.stringify(item)} on ${module.filename}`);
            return response.status(201).json(item);
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao inserir Item: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
        
        /*
        {
            "sku": "abc123dfg-4",
            "descricao": "notebook Dell,
            "valor": 3500.90,
            "quantidade": 1,
            "cliente_id": 1
        }
        */ 
    },
    
    //PUT ==> Udate de Item
    async update(request: Request, response: Response) {
        const{
            id,
            sku,
            descricao,
            valor,
            quantidade,
            created_at,
            cliente_id,
            modified_at
        } = request.body;
        const itensRepository = getRepository(Item);
        let data = {
            id,
            sku,
            descricao,
            valor,
            quantidade,
            created_at,
            cliente_id,
            modified_at
        }
        const now = new Date;
        data.modified_at = now;
        const schema = Yup.object().shape({
        id         : Yup.number()
                    .required('Para update é necessário informar o ID')
                    .typeError("O ID informado não é numérico"),
        sku        : Yup.string()
                    .required('Nome é um campo obrigatório'),
        descricao  : Yup.string()
                    .required('Descrição é um campo obrigatório'),
        valor      : Yup.number()
                    .required('Valor é um campo obrigatório')
                    .typeError("O valor informado não é numérico"),
        quantidade : Yup.number()
                    .required('Quantidade é um campo obrigatório')
                    .typeError("O valor informado não é numérico"),
        cliente_id : Yup.number()
                    .required('Quantidade é um campo obrigatório')
                    .typeError("O valor informado não é numérico")
        })
        await schema.validate(data, {
            abortEarly: false
        });
        const item = itensRepository.create(data);
        try {
            await itensRepository.update(
                { id: data.id },
                item
            );
            var loggererror = log4js.getLogger('info');
            loggererror.info(`Alterado com sucesso: ${JSON.stringify(item)} on ${module.filename}`);
            return response.status(201).json(item);
        } catch (error) {
            var loggererror = log4js.getLogger('error');
            loggererror.error(`Erro ao executar o update de Item: ${error.message} on ${module.filename}`);
            return response.status(400).json({"message" : "Ocorreu o seguinte erro", "Error" : error.message});
        }
    }
};