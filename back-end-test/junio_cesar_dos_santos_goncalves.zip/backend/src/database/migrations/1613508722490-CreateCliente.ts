import {MigrationInterface, QueryRunner, Table} from "typeorm";

export class CreateCliente1613508722490 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.createTable( new Table({
            name: 'clientes',
            columns: [
                {
                    name: 'id',
                    type: 'integer',
                    unsigned: true,
                    isPrimary: true,
                    isGenerated: true,
                    generationStrategy: 'increment',
                },
                {
                    name: 'nome',
                    type: 'varchar(100)',
                    isNullable: false
                },
                {
                    name: 'email',
                    type: 'varchar(60)',
                    isNullable: false
                },
                {
                    name: 'cpf',
                    type: 'varchar(15)',
                    isNullable: false
                },
                {
                    name: 'cep',
                    type: 'varchar(10)',
                    isNullable: false
                },
                {
                    name: 'frete',
                    type: 'decimal',
                    scale: 2,
                    precision: 2,
                    isNullable: false,
                },
                {
                    name: 'valor',
                    type: 'decimal',
                    scale: 2,
                    precision: 2,
                    isNullable: false,
                },
                {
                    name: 'created_at',
                    type: 'datetime',
                    //default: 'now()'
                },
                {
                    name: 'modified_at',
                    type: 'datetime',
                    isNullable: true,
                    //default: 'now()'
                }
            ]
        }));
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.dropTable('clientes');
    }

}
