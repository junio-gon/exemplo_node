import { Router } from 'express';
import clientesController from './controller/ClientesController';
import itensController from './controller/ItensController';

const routes = Router();

//Clientes routes
routes.get('/clientes', clientesController.index);
routes.get('/clientes/:id', clientesController.show);
routes.post('/clientes', clientesController.create);
routes.put('/clientes', clientesController.update);
routes.delete('/clientes/:id', clientesController.delete);

//Itens routes
routes.get('/itens', itensController.index);
routes.get('/itens/:id', itensController.show);
routes.post('/itens', itensController.create);
routes.put('/itens', itensController.update);
routes.delete('/itens/:id', itensController.delete);

export default routes;