import Cliente from '../models/cliente'

export default{
    render(cliente: Cliente){
        return{
            id: cliente.id,
            nome: cliente.nome,
            email: cliente.email,
            cpf: cliente.cpf,
            cep: cliente.cep,
            frete: cliente.frete,
            valor: cliente.valor,
            created_at: cliente.created_at,
            modified_at: cliente.modified_at,
        };
    },
    renderMany(clientes: Cliente[]){
        return clientes.map( cliente => this.render(cliente));
    }
}