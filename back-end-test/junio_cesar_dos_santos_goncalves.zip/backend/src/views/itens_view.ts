import Item from '../models/item'

export default{
    render(item: Item){
        return{
            id: item.id,
            sku: item.sku,
            descricao: item.descricao,
            valor: item.valor,
            quantidade: item.quantidade,
            created_at: item.created_at,
            modified_at: item.modified_at,
            //option: item.option
        };
    },
    renderMany(item: Item[]){
        return item.map( item => this.render(item));
    }
}